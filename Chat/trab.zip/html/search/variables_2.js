var searchData=
[
  ['ip_5faddress_39',['IP_address',['../namespace_client.html#abb2d84d85a216b997605c6522d1c4983',1,'Client.IP_address()'],['../namespace_server.html#a712499c588b8c9d420bf7e1a3f32521a',1,'Server.IP_address()']]]
];
