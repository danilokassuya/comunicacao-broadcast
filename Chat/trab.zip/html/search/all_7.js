var searchData=
[
  ['sendtoanotherserver_18',['sendToAnotherServer',['../namespace_server.html#a33adc04b241fe260e3f1e4e94091b8fb',1,'Server']]],
  ['server_19',['Server',['../namespace_server.html',1,'']]],
  ['server_20',['server',['../namespace_server.html#a1118e181246756b8f46311fc864e0297',1,'Server']]],
  ['server_2epy_21',['Server.py',['../_server_8py.html',1,'']]]
];
