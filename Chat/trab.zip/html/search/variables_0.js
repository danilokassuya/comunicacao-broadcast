var searchData=
[
  ['client_35',['client',['../namespace_client.html#a084b845ba369e66e2fccb165382b5544',1,'Client']]],
  ['clients_36',['clients',['../namespace_server.html#a3a587602029a0e8caf71972a13383291',1,'Server']]]
];
