var searchData=
[
  ['receive_31',['receive',['../namespace_client.html#ae9df604d38e343ae242adac7b887a662',1,'Client.receive()'],['../namespace_server.html#ab9d00ec901183f31c044be6a3e7dfcec',1,'Server.receive()']]],
  ['receiveserver_32',['receiveServer',['../namespace_server.html#a10f4cb8ffa09595cb47964c7e8cfe141',1,'Server']]]
];
