var searchData=
[
  ['nickname_10',['nickname',['../namespace_client.html#ab23b06fa7f1d0d2d3a36c01b96e9f06f',1,'Client']]],
  ['nicknames_11',['nicknames',['../namespace_server.html#a700d69ce8e18d66f566688bba82c5d13',1,'Server']]]
];
