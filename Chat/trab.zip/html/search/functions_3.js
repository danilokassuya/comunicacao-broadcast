var searchData=
[
  ['sendtoanotherserver_33',['sendToAnotherServer',['../namespace_server.html#a33adc04b241fe260e3f1e4e94091b8fb',1,'Server']]]
];
