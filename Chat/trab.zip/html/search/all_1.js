var searchData=
[
  ['client_1',['Client',['../namespace_client.html',1,'']]],
  ['client_2',['client',['../namespace_client.html#a084b845ba369e66e2fccb165382b5544',1,'Client']]],
  ['client_2epy_3',['Client.py',['../_client_8py.html',1,'']]],
  ['clients_4',['clients',['../namespace_server.html#a3a587602029a0e8caf71972a13383291',1,'Server']]]
];
