var searchData=
[
  ['handle_29',['handle',['../namespace_server.html#acf7ca7dbf2bd3d673bf2628a9779a8fb',1,'Server']]],
  ['handleserver_30',['handleServer',['../namespace_server.html#a47f6bd6a840a9d3597f653a726ce188d',1,'Server']]]
];
