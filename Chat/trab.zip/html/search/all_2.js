var searchData=
[
  ['handle_5',['handle',['../namespace_server.html#acf7ca7dbf2bd3d673bf2628a9779a8fb',1,'Server']]],
  ['handleserver_6',['handleServer',['../namespace_server.html#a47f6bd6a840a9d3597f653a726ce188d',1,'Server']]],
  ['historico_7',['historico',['../namespace_server.html#ac9c48cb07ffa5813f24dfb082a83fc8e',1,'Server']]],
  ['host_8',['host',['../namespace_server.html#a844061ad126c3c8ffe6c2c7440a696fe',1,'Server']]]
];
