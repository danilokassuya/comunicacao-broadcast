var searchData=
[
  ['server_2epy_27',['Server.py',['../_server_8py.html',1,'']]]
];
