var searchData=
[
  ['client_2epy_26',['Client.py',['../_client_8py.html',1,'']]]
];
