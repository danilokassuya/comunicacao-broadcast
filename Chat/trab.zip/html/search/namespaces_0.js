var searchData=
[
  ['client_24',['Client',['../namespace_client.html',1,'']]]
];
