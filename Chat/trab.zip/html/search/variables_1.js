var searchData=
[
  ['historico_37',['historico',['../namespace_server.html#ac9c48cb07ffa5813f24dfb082a83fc8e',1,'Server']]],
  ['host_38',['host',['../namespace_server.html#a844061ad126c3c8ffe6c2c7440a696fe',1,'Server']]]
];
