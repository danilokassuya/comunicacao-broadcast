var searchData=
[
  ['receive_5fthread_45',['receive_thread',['../namespace_client.html#ab225cf3162f2a640997808da6b58a34e',1,'Client.receive_thread()'],['../namespace_server.html#a9f15c04c1095a4ab224ad5b42cf49ab6',1,'Server.receive_thread()']]]
];
